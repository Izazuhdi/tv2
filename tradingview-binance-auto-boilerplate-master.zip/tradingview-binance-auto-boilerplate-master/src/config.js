export default {
  apiKey: "",
  apiSecret: "",
}